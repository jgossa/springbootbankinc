CREATE DataBase test;
CREATE SCHEMA bankinc;